function y=cec17_funcMex(x,func_num)
global fbias
global GFES
y=cec17_func(x,func_num)-fbias(func_num);
GFES=GFES+size(x,2);
end