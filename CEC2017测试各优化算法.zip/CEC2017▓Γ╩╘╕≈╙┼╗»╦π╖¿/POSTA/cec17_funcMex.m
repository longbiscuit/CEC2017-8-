function y=cec17_funcMex(x,func_num)
global fbias
global FESs
% if iscell(func_num)
%     fn=func_num{:};
% else
%      fn=func_num;
% end
y=cec17_func(x',func_num)-fbias(func_num);
[m,n]=size(x');
FESs=FESs+n;
end