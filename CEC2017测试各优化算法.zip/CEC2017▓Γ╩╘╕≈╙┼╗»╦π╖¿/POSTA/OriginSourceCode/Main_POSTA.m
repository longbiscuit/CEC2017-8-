% Binglong Zhu, 2021-12-9，blzhu@buaa.edu.cn
% Reference: https://faculty.csu.edu.cn/michael_x_zhou/zh_CN/jxzy/74762/content/1459.htm#jxzy

% Modify: Some languages are not convenient to operate matrix, need to be 
% realized by ‘for’ cycle, so the matrix operation of the four operators
% is transformed into a ‘for’  cycle operation  

%-----------------------main------------------------
clear all
clc
close all
% currentFolder = pwd;
% addpath(genpath(currentFolder))
% parameter setting
warning('off')
% VarMin=[-5.12 -5.12 -5.12 -5.12 -5.12 -5.12];
% VarMax=[5.12 5.12 5.12 5.12 5.12 5.12];
VarMin=-1500*ones(1,10);
VarMax=3000*ones(1,10);

SE =  30; % degree of search enforcement,SE个个体
Dim = numel(VarMin);% dimension 100个参数要求解

% Range = repmat([-5.12;5.12],1,Dim);%range为2行100列
Range = [VarMin;VarMax];%range为2行100列
tic
[Best,fBest,history] = STA(@ackley,SE,Dim,Range);
toc
figure(1)
semilogy(history)
figure(2)
plot(Best,'r*')

%-----------------------STA------------------------
function [Best,fBest,history] = STA(funfcn,SE,Dim,Range)

global iterGbestval;
global BestSol;

 rand('state',sum(100*clock))
% rng('shuffle')
%
State = initialization(SE,Dim,Range);
[Best,fBest] = fitness(funfcn,State);


Omega = [1,1e-1,1e-2,1e-3,1e-4,1e-5,1e-6,1e-7,1e-8];
% Omega = [1,1e-1,1e-2,1e-3,1e-4,1e-5,1e-6,1e-7,1e-8,1e-9,1e-10,1e-11,1e-12,1e-13,1e-14,1e-15];

%
iter = 0;
counter = 0;
while(1)
    oldfBest = fBest;
    [Best,fBest] = expand_w(funfcn,Best,SE,Range,Omega);
    [Best,fBest] = rotate_w(funfcn,Best,SE,Range,Omega);
    [Best,fBest] = axesion_w(funfcn,Best,SE,Range,Omega);
    iter = iter + 1;
    %  termination conditions
    if fBest>oldfBest
        disp('error?');%不可能出现才对
    end
    if norm(oldfBest-fBest) < 1e-10 % can be changed
        counter = counter + 1;
        if counter > 20 % can be changed
            break;
        end
    else
        counter = 0;
    end
    %     fprintf('iter=%d      ObjVal=%g\n',iter,fBest);
    history(iter) = fBest;
    disp(['iter=' num2str(iter)  ',gbest_fitness=' num2str(fBest) ',gbest_position= ' num2str(Best) ]);
    iterGbestval=[iterGbestval ;[iter,fBest]];
    %     plot(Best,'r*')
    %    pause(1)
end
BestSol.Position=Best;
BestSol.Cost=fBest;
end

%-----------------------initialization------------------------
function  State=initialization(SE,Dim,Range)
Pop_Lb = Range(1,:);%所有维度的下限VarMin
Pop_Ub = Range(2,:);%所有维度的上限VarMax
State  = rand(SE,Dim).*repmat(Pop_Ub-Pop_Lb,SE,1)+repmat(Pop_Lb,SE,1);%30行100列，30个个体
end

%-----------------------expand_w------------------------
function [Best,fBest] = expand_w(funfcn,Best,SE,Range,Omega)
[Best,gamma] = update_gamma(funfcn,Best,SE,Range,Omega);
for i = 1:10
    [Best,fBest] = expand(funfcn,Best,SE,Range,gamma);
    
end
end

%-----------------------rotate_w------------------------
function [Best,fBest] = rotate_w(funfcn,Best,SE,Range,Omega)
[Best,alpha] = update_alpha(funfcn,Best,SE,Range,Omega);
for i = 1:10
    [Best,fBest] = rotate(funfcn,Best,SE,Range,alpha);
end
end

%-----------------------axesion_w------------------------
function [Best,fBest] = axesion_w(funfcn,Best,SE,Range,Omega)
[Best,delta] = update_delta(funfcn,Best,SE,Range,Omega);
for i = 1:10
    [Best,fBest] = axesion(funfcn,Best,SE,Range,delta);
end
end

%-----------------------update_gamma------------------------
function [Best,gamma] = update_gamma(funfcn,Best,SE,Range,Omega)
Pop_Lb = repmat(Range(1,:),SE,1);
Pop_Ub = repmat(Range(2,:),SE,1);
m  = length(Omega);
fBest = feval(funfcn,Best);
gamma = 1;
Best0 = Best;
for i = 1:m
    State = op_expand(Best0,SE,Omega(i)); %
    %Apply  for State > Pop_Ub or State < Pop_Lb
    changeRows = State > Pop_Ub;
    State(find(changeRows)) = Pop_Ub(find(changeRows));
    changeRows = State < Pop_Lb;
    State(find(changeRows)) = Pop_Lb(find(changeRows));
    %Apply  for State > Pop_Ub or State < Pop_Lb
    [tempBest,tempfBest] = fitness(funfcn,State);
    if tempfBest < fBest
        Best = tempBest;
        fBest = tempfBest;
        gamma = Omega(i);
    end
end
end

%-----------------------expand------------------------
function [Best,fBest,flag] = expand(funfcn,oldBest,SE,Range,gamma)
beta = 1;
Pop_Lb = repmat(Range(1,:),SE,1);
Pop_Ub = repmat(Range(2,:),SE,1);

Best = oldBest;
fBest  = feval(funfcn,Best);

State = op_expand(Best,SE,gamma); %
%Apply  for State > Pop_Ub or State < Pop_Lb
changeRows = State > Pop_Ub;
State(find(changeRows)) = Pop_Ub(find(changeRows));
changeRows = State < Pop_Lb;
State(find(changeRows)) = Pop_Lb(find(changeRows));
%Apply  for State > Pop_Ub or State < Pop_Lb
[newBest,fGBest] = fitness(funfcn,State);
if fGBest < fBest
    fBest = fGBest;
    Best = newBest;
    flag = 1;
else
    flag = 0;
end

if flag ==1
    State = op_translate(oldBest,Best,SE,beta);%
    %Apply  for State > Pop_Ub or State < Pop_Lb
    changeRows = State > Pop_Ub;
    State(find(changeRows)) = Pop_Ub(find(changeRows));
    changeRows = State < Pop_Lb;
    State(find(changeRows)) = Pop_Lb(find(changeRows));
    %Apply  for State > Pop_Ub or State < Pop_Lb
    [newBest,fGBest] = fitness(funfcn,State);
    if fGBest < fBest
        fBest = fGBest;
        Best = newBest;
    end
end
end

%-----------------------update_alpha------------------------
function [Best,alpha] = update_alpha(funfcn,Best,SE,Range,Omega)
Pop_Lb = repmat(Range(1,:),SE,1);
Pop_Ub = repmat(Range(2,:),SE,1);
m  = length(Omega);
fBest = feval(funfcn,Best);
alpha = 1;
Best0 = Best;
for i = 1:m
    State = op_rotate(Best0,SE,Omega(i)); %
    %Apply  for State > Pop_Ub or State < Pop_Lb
    changeRows = State > Pop_Ub;
    State(find(changeRows)) = Pop_Ub(find(changeRows));
    changeRows = State < Pop_Lb;
    State(find(changeRows)) = Pop_Lb(find(changeRows));
    %Apply  for State > Pop_Ub or State < Pop_Lb
    [tempBest,tempfBest] = fitness(funfcn,State);
    if tempfBest < fBest
        Best = tempBest;
        fBest = tempfBest;
        alpha = Omega(i);
    end
end
end

%-----------------------rotate------------------------
function [Best,fBest,flag] = rotate(funfcn,oldBest,SE,Range,alpha)
beta = 1;
Pop_Lb = repmat(Range(1,:),SE,1);
Pop_Ub = repmat(Range(2,:),SE,1);

Best = oldBest;
fBest  = feval(funfcn,Best);

State = op_rotate(Best,SE,alpha); %
%Apply  for State > Pop_Ub or State < Pop_Lb
changeRows = State > Pop_Ub;
State(find(changeRows)) = Pop_Ub(find(changeRows));
changeRows = State < Pop_Lb;
State(find(changeRows)) = Pop_Lb(find(changeRows));
%Apply  for State > Pop_Ub or State < Pop_Lb
[newBest,fGBest] = fitness(funfcn,State);
if fGBest < fBest
    fBest = fGBest;
    Best = newBest;
    flag = 1;
else
    flag = 0;
end

if flag ==1
    State = op_translate(oldBest,Best,SE,beta);%
    %Apply  for State > Pop_Ub or State < Pop_Lb
    changeRows = State > Pop_Ub;
    State(find(changeRows)) = Pop_Ub(find(changeRows));
    changeRows = State < Pop_Lb;
    State(find(changeRows)) = Pop_Lb(find(changeRows));
    %Apply  for State > Pop_Ub or State < Pop_Lb
    [newBest,fGBest] = fitness(funfcn,State);
    if fGBest < fBest
        fBest = fGBest;
        Best = newBest;
    end
end
end

%-----------------------update_delta------------------------
function [Best,delta] = update_delta(funfcn,Best,SE,Range,Omega)
Pop_Lb = repmat(Range(1,:),SE,1);
Pop_Ub = repmat(Range(2,:),SE,1);
m  = length(Omega);
fBest = feval(funfcn,Best);
delta = 1;
Best0 = Best;
for i = 1:m
    State = op_axes(Best0,SE,Omega(i)); %
    %Apply  for State > Pop_Ub or State < Pop_Lb
    changeRows = State > Pop_Ub;
    State(find(changeRows)) = Pop_Ub(find(changeRows));
    changeRows = State < Pop_Lb;
    State(find(changeRows)) = Pop_Lb(find(changeRows));
    %Apply  for State > Pop_Ub or State < Pop_Lb
    [tempBest,tempfBest] = fitness(funfcn,State);
    if tempfBest < fBest
        Best = tempBest;
        fBest = tempfBest;
        delta = Omega(i);
    end
end
end

%-----------------------axesion------------------------
function [Best,fBest,flag] = axesion(funfcn,oldBest,SE,Range,delta)
beta = 1;
Pop_Lb = repmat(Range(1,:),SE,1);
Pop_Ub = repmat(Range(2,:),SE,1);

Best = oldBest;
fBest  = feval(funfcn,Best);


State = op_axes(Best,SE,delta); %
%Apply  for State > Pop_Ub or State < Pop_Lb
changeRows  = State  > Pop_Ub ;
State(find(changeRows)) = Pop_Ub(find(changeRows));
changeRows  = State  < Pop_Lb;
State(find(changeRows)) = Pop_Lb(find(changeRows));
%Apply  for State > Pop_Ub or State < Pop_Lb
[newBest,fGBest] = fitness(funfcn,State);
if fGBest < fBest
    fBest = fGBest;
    Best = newBest;
    flag = 1;
else
    flag = 0;
end

if flag ==1
    State = op_translate(oldBest,Best,SE,beta);%
    %Apply  for State > Pop_Ub or State < Pop_Lb
    changeRows = State > Pop_Ub;
    State(find(changeRows)) = Pop_Ub(find(changeRows));
    changeRows = State < Pop_Lb;
    State(find(changeRows)) = Pop_Lb(find(changeRows));
    %Apply  for State > Pop_Ub or State < Pop_Lb
    [newBest,fGBest] = fitness(funfcn,State);
    if fGBest < fBest
        fBest = fGBest;
        Best = newBest;
    end
end
end

%-----------------------op_rotate_zbl------------------------
function y = op_rotate(Best,SE,alpha)
% 局部 旋转
% n = length(Best);
% R1 = 2*rand(SE,n)-1;
% R2 = 2*rand(SE,1)-1;
% y = repmat(Best,SE,1) + alpha*repmat(R2,1,n).*R1./repmat(sqrt(sum(R1.*R1,2)),1,n);

%分解
% n = length(Best);
% R1 = 2*rand(SE,n)-1;%SE行n列的矩阵
% R2 = 2*rand(SE,1)-1;
% A=repmat(Best,SE,1);%形状和R1相同
% B=repmat(R2,1,n);%形状和R1也相同
% C=sqrt(sum(R1.*R1,2));%R1和R1每个元素之积，形状和R1相同，然后对行元素求和。最后形状和R2相同； sum(A,2) is a column vector containing the sum of each row.
% y= A+ alpha*B.*R1./repmat(C,1,n);%

%改写上面的超球体代码为循环形式，用于改编为有些不支持矩阵操作的语言
n = length(Best);
State=zeros(SE,n);
for ii=1:SE
    F2=0.0;
    for dd=1:n
        R1(dd)=2*rand-1;
        F2=F2+ R1(dd)^2;
    end
    F2=sqrt(F2)+eps;
    C=F2;
    R2=2*rand-1;
    for dd=1:n
        State(ii,dd)=Best(dd)+alpha*R2*R1(dd)/C;%注意这儿一行是一组
    end
end
y=State;

% %论文中公式 超立方体
% n = length(Best);
% State=zeros(SE,n);
% F2=0.0;
% for dd=1:n
%     F2=F2+ Best(dd)^2;
% end
% F2=sqrt(F2)+eps;
% for ii=1:SE
%     for dd=1:n
%         R1=2*rand-1;
%         State(ii,dd)=Best(dd)+alpha*R1*Best(dd)/(n*F2);%注意这儿一行是一组
%     end
% end
% y=State;
end

%-----------------------op_translate_zbl------------------------
function y = op_translate(oldBest,newBest,SE,beta)
% 局部搜索 一条线
%原始代码
% n = length(oldBest);
% y = repmat(newBest',1,SE) + beta/(norm(newBest-oldBest)+eps)*reshape(kron(rand(SE,1),(newBest-oldBest)'),n,SE);
% y = y';

% A=[1 2;3 4]
% B=[4 3 ;2 1]
% C=kron(A,B)
%分解
% n = length(oldBest);
% A=repmat(newBest',1,SE);%n*SE
% B=norm(newBest-oldBest)+eps;
% C=kron(rand(SE,1),(newBest-oldBest)');
% y = A + beta/B*reshape(C,n,SE);


%改写上面为循环形式，用于改编为有些不支持矩阵操作的语言
n = length(oldBest);
State=zeros(SE,n);
F2=0.0;
for dd=1:n
    F2=F2+ (newBest(dd)- oldBest(dd))^2;
end
F2=sqrt(F2)+eps;
B=F2;
for ii=1:SE
    R1=rand;
    for dd=1:n
        State(ii,dd)=newBest(dd)+beta/B*R1*(newBest(dd)-oldBest(dd));%注意这儿一行是一组
    end
end
y=State;

end

%-----------------------op_expand_zbl------------------------
function y = op_expand(Best,SE,gamma)
% 全局搜索
% n = length(Best);
% y = repmat(Best',1,SE) + gamma*(normrnd(0,1,n,SE).*repmat(Best',1,SE));
% y = y';

% 分解
% n = length(Best);
% A= repmat(Best',1,SE);%n*SE
% B=normrnd(0,1,n,SE);%n*SE
% y = A+ gamma*(B.*A);
% y = y';

%改写上方代码，用于改编为有些不支持矩阵操作的语言
n = length(Best);
State=zeros(SE,n);
for ii=1:SE
    for dd=1:n
        %         State(ii,dd)=Best(dd)+gamma*(normrnd(0,1)*Best(dd));%注意这儿一行是一组
        State(ii,dd)=Best(dd)*(1+gamma*(normrnd(0,1)));%注意这儿一行是一组
    end
end
y=State;

end

%-----------------------op_axes_zbl------------------------
function y = op_axes(Best,SE,delta)
% 全局搜索 坐标变换
% 源代码
% n = length(Best);
% A = zeros(n,SE);
% index = randi([1,n],1,SE);
% A(n*(0:SE-1)+index) = 1;
% y = repmat(Best',1,SE) + delta*normrnd(0,1,n,SE).*A.*repmat(Best',1,SE);
% y = y';

% 改写上面为循环形式，用于改编为有些不支持矩阵操作的语言
n = length(Best);
for ii=1:SE
    OneIndex=randi([1 n]);
    for dd=1:n
        if dd==OneIndex
            State(ii,dd)=Best(dd)+delta*normrnd(0,1)*Best(dd);%注意这儿一行是一组
        else
            State(ii,dd)=Best(dd)+delta*0*Best(dd);% 注意这儿一行是一组
        end
    end
end
y=State;
end

%-----------------------op_axes_zbl------------------------
function [Best,fBest] = fitness(funfcn,State)
% calculate fitness
SE = size(State,1);
fState = zeros(SE,1);
for i = 1:SE
    fState(i) = feval(funfcn,State(i,:));
end
[fGBest, g] = min(fState);
fBest = fGBest;
Best = State(g,:);
end

