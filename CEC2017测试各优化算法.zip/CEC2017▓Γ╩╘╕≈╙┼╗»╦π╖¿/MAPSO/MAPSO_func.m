function [gbest,gbestval,fitcount,suc,suc_fes]= MAPSO_func(jingdu,func_num,fhd,Dimension,group_size,group_num,Max_Gen,Max_FES,Xmin,Xmax,varargin)
                                                
%%%%%%%%
% global orthm   initial_flag gbias
% global  fbias 
fbias=[100, 200, 300, 400, 500,...
       600, 700, 800, 900, 1000,...
       1100,1200,1300,1400,1500,...
       1600,1700,1800,1900,2000,...
       2100,2200,2300,2400,2500,...
       2600,2700,2800,2900,3000 ];
   
rand('state',sum(100*clock));
me=Max_Gen;
D=Dimension;
fitcount=0;
ps=group_size*group_num; % �ܸ�����=����Ⱥ��ģ*����Ⱥ����
ps_ini=ps;
up_ps=ps;
% group_size Ϊ����Ⱥ��ģ��group_num Ϊ����Ⱥ�ĸ���
sizeof_Ae=group_num;
sizeof_Ap=group_num;
sizeof_Ax=ps;
R1=10; % ��������
R2=100; % ɾ�����Ƹ��������

lu=[repmat(Xmin,1,D); repmat(Xmax,1,D)];

%% Initialize population ------------------------------------------

tmpN = 100*D;
pos1=zeros(tmpN,D);
for i=1:tmpN
    pos1(i,:)=lu(1,:)+(lu(2,:)-lu(1,:)).*rand(1,D);
end
tmpe1=feval(fhd,pos1',varargin{:})-fbias(func_num);
fitcount=fitcount+tmpN;

radius=(Xmax-Xmin)/tmpN; 
pos2=pos1+((rand(tmpN,D)-1)*radius);
for i=1:tmpN
    pos2(i,:)=(pos2(i,:)>lu(2,:)).*lu(2,:)+(pos2(i,:)<=lu(2,:)).*pos2(i,:); 
    pos2(i,:)=(pos2(i,:)<lu(1,:)).*lu(1,:)+(pos2(i,:)>=lu(1,:)).*pos2(i,:);
end
tmpe2=feval(fhd,pos2',varargin{:})-fbias(func_num);
fitcount=fitcount+tmpN;

%% Initialize Ae �� Ap ------------------------------
% 
tmpe=inf(1,tmpN);    tmppos=zeros(tmpN,D);
delta_e=inf(1,tmpN); delta_pos=zeros(1,tmpN);
for i=1:tmpN
   if tmpe1(1,i)<tmpe2(1,i)
       tmpe(1,i)=tmpe1(1,i);   tmppos(i,:)=pos1(i,:); 
   else
       tmpe(1,i)=tmpe2(1,i);   tmppos(i,:)=pos2(i,:);
   end
   
   delta_e(1,i)=tmpe1(1,i)-tmpe2(1,i);        
   delta_pos(1,i)=norm(pos2(i,:)-pos1(i,:)); 
end

[B, IX]=sort(tmpe,'ascend');                
e=B(1:ps); pos(1:ps,:)=tmppos(IX(1:ps),:);  
pbest=pos; pbestval=e;
mv=0.2.*(lu(2,:)-lu(1,:));
Vmin=repmat(-mv,ps,1);
Vmax=-Vmin;
vel=Vmin+2.*Vmax.*rand(ps,D);

% pos=zeros(ps,D);
% mv=0.2.*(lu(2,:)-lu(1,:));
% Vmin=repmat(-mv,ps,1);
% Vmax=-Vmin;
% pos=repmat(lu(1,:),ps,1)+(repmat(lu(2,:),ps,1)-repmat(lu(1,:),ps,1)).*rand(ps,D);
% vel=Vmin+2.*Vmax.*rand(ps,D);
% 
% e=feval(fhd,pos',varargin{:})-fbias(func_num);
% fitcount=ps;
% pbest=pos; pbestval=e;

%% regroup
for i=1:group_num
    group_id(i,:)=[((i-1)*group_size+1):i*group_size];
    pos_group(group_id(i,:))=i;
    %%%%%%%%%%%%%%%%%%%%%%%
    [val, IX]=sort(e(group_id(i,:)),'ascend');    
    subgbest(i,:)=pos(group_id(i,IX(1)),:);                 
    subgbestval(i)=e(group_id(i,IX(1)));
    subgbest_p(i,:)=pbest(group_id(i,IX(1)),:);               
    subgbest_pv(i)=pbestval(group_id(i,IX(1)));
    
    subgmid(i,:)=pos(group_id(i,IX(2)),:);                 
    subgmidval(i)=e(group_id(i,IX(2)));
    subgmid_p(i,:)=pos(group_id(i,IX(2)),:);                 
    subgmid_pv(i)=e(group_id(i,IX(2)));
    
    subgworst(i,:)=pos(group_id(i,IX(3)),:);                
    subgworstval(i)=e(group_id(i,IX(3)));
    subgworst_p(i,:)=pos(group_id(i,IX(3)),:);                
    subgworst_pv(i)=e(group_id(i,IX(3)));

end

[gbestval,gbestid]=min(pbestval);
gbest=pbest(gbestid,:);

% 
elites_size=group_num;
elites_val=subgbestval; 
elites_pos=subgbest;

prob_elite=elites_size:-1:1;
prob_elite=prob_elite/sum(prob_elite);   

pmAve=sum(elites_pos)/elites_size;
pmVar=sqrt(sum((elites_pos-repmat(pmAve,elites_size,1)).^2)/elites_size);
rate=0.5;

oldgbestval=gbestval;
improved=0;  
stagnated=0;
%%
archive_maxsize = ps; 

recorded = 0; 
suc = 0;
suc_fes = 0;

iter=1;


%% Main loop
while fitcount<Max_FES && iter<me %ini_ratio*Max_FES  %ps>ps_ini/3  % 

    group_flag=zeros(group_num,2);
    for j=1:ps 
       
        if e(j)==subgbestval(pos_group(j))&&group_flag(pos_group(j),1)==0     
            group_flag(pos_group(j),1)=1;
            paraIndex=1;    
        elseif e(j)==subgworstval(pos_group(j))&&group_flag(pos_group(j),2)==0
            group_flag(pos_group(j),2)=1;
            paraIndex=2; 
        else                                  
            paraIndex=3;  
        end
        
        switch paraIndex
            case 1  
                parent=[subgbest]; %[subgworst;subgmid;subgbest]; %
                parent_val=[subgbestval];
                parent=[subgbest_p]; %[subgworst;subgmid;subgbest]; %
                parent_val=[subgbest_pv];
            case 2
                parent=[subgworst;subgmid;subgbest]; %subgworst;%
                parent_val=[subgworstval,subgmidval,subgbestval];
                parent=[subgworst_p;subgmid_p;subgbest_p]; %subgworst;%
                parent_val=[subgworst_pv,subgmid_pv,subgbest_pv];
            case 3
                parent=[subgmid;subgbest]; %[subgworst;subgmid;subgbest]; %subgmid;%
                parent_val=[subgmidval,subgbestval];
                parent=[subgworst_p;subgmid_p;subgbest_p]; %[subgmid_p;subgbest_p]; %subgmid;%
                parent_val=[subgworst_pv,subgmid_pv,subgbest_pv];
        end
    
        %-------------------------------------
        parent_size=size(parent,1);
        [pos(j,:), vel(j,:)]= Breed_offspring(pos(j,:), vel(j,:), pbest(j,:), pbestval(j), subgbest(pos_group(j),:), subgbestval(pos_group(j)), gbest, ...
                                              parent, parent_size, parent_val, mv, D, paraIndex, fitcount, Max_FES);
                     
        if rand<0.2
            pos(j,:)=(pos(j,:)>lu(2,:)).*lu(2,:)+(pos(j,:)<=lu(2,:)).*pos(j,:); 
            pos(j,:)=(pos(j,:)<lu(1,:)).*(lu(1,:))+(pos(j,:)>=lu(1,:)).*pos(j,:);
        else
            pos(j,:)=((pos(j,:)>=lu(1,:))&(pos(j,:)<=lu(2,:))).*pos(j,:)...
                +(pos(j,:)<lu(1,:)).*(lu(1,:)+0.1.*(lu(2,:)-lu(1,:)).*rand(1,D))...
                +(pos(j,:)>lu(2,:)).*(lu(2,:)-0.1.*(lu(2,:)-lu(1,:)).*rand(1,D));
        end

    end    

    e=feval(fhd,pos(1:ps,:)',varargin{:})-fbias(func_num);
    fitcount=fitcount+ps;
   
    %% Update pbest and gbest
    pbestval=(e>pbestval).*pbestval+(e<=pbestval).*e;
    pbest=repmat((e>pbestval)',1,D).*pbest+repmat((e<=pbestval)',1,D).*pos;
    [gbestval, IX]=min(pbestval);
    gbest=pbest(IX(1),:);
    
    %%
    for i=1:group_num    
        %%%%%%%%%%%%%%%%%%%%%%%    
        [elite_val_added(i), IX]=min(pbestval(group_id(i,:)));
        elite_pos_added(i,:)=pbest(group_id(i,IX),:);
       
        %%%%%%%%%%%%%%%%%%%%%%  
        [pv, IX]=sort(e(group_id(i,:)),'ascend');        
        subgbestval(i)=pv(1);
        subgbest(i,:)=pos(group_id(i,IX(1)),:);                      
        subgmidval(i)=pv(2);
        subgmid(i,:)=pos(group_id(i,IX(2)),:);                         
        subgworstval(i)=pv(3);
        subgworst(i,:)=pos(group_id(i,IX(3)),:);                      
        
        [pv, IX]=sort(pbestval(group_id(i,:)),'ascend');
        subgbest_p(i,:)=pbest(group_id(i,IX(1)),:);             
        subgbest_pv(i)=pbestval(group_id(i,IX(1)));
        subgmid_p(i,:)=pbest(group_id(i,IX(2)),:);             
        subgmid_pv(i)=pbestval(group_id(i,IX(2)));
        subgworst_p(i,:)=pbest(group_id(i,IX(3)),:);           
        subgworst_pv(i)=pbestval(group_id(i,IX(3)));

     end    

    elites_pos=[elites_pos; elite_pos_added]; elites_val=[elites_val, elite_val_added];
    tmp_elites=[elites_pos, elites_val'];      
    tmp_elites=unique(tmp_elites,'rows'); 
    tmp_elites=sortrows(tmp_elites,D+1); 
    if elites_size>size(tmp_elites,1)
        add_size=elites_size-size(tmp_elites,1);
%         add_IX=randperm(size(tmp_elites,1));
        for i=1:add_size
            add_IX=randperm(size(tmp_elites,1));
            tmp_elites(size(tmp_elites,1)+i,:)=tmp_elites(add_IX(1),:);
        end
    end
    elites_val=tmp_elites(1:elites_size,D+1)';
    elites_pos=tmp_elites(1:elites_size,1:D);
             
    if gbestval<oldgbestval
        oldgbestval=gbestval;
        improved=improved+1;
        stagnated=0;
        % 
%         [elites_val, elites_pos]=Add2archive(elites_val, elites_pos, elites_size, gbest, gbestval);
    else
        improved=0;
        stagnated=stagnated+1;
    
    end
       
    %   
    pmAve=(1-rate)*pmAve+rate*(sum(elites_pos(1:elites_size,:))/double(elites_size));
    pmVar=(1-rate)*pmVar+rate*sqrt(sum(((elites_pos(1:elites_size,:)-repmat(pmAve,elites_size,1)).^2)/double(elites_size)));
                
    %% 
    maxImp=2; maxStag=2;  %

    delete_group=2; add_group=1; replace_group=1;  % 
    
    if  improved>=maxImp && ps>ps_ini/3   
        improved=0;
        
        [~, deleted_IX]=sort(e,'descend');
        e(deleted_IX(1:group_size*delete_group))=[];      
        pos(deleted_IX(1:group_size*delete_group),:)=[];  
        vel(deleted_IX(1:group_size*delete_group),:)=[];
        pbestval(deleted_IX(1:group_size*delete_group))=[];
        pbest(deleted_IX(1:group_size*delete_group),:)=[];
        
        ps=ps-group_size*delete_group;                   
        group_num=group_num-delete_group;                
       
        rc=randperm(ps);
        group_id=[];pos_group=[];
        subgbestval=[];subgbest=[];
        subgmidval=[];subgmid=[];
        subgworstval=[];subgworst=[];
        for k=1:group_num
            group_id(k,:)=rc(((k-1)*group_size+1):k*group_size);
            pos_group(group_id(k,:))=k;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%
            [val, IX]=sort(e(group_id(k,:)),'ascend');  
            subgbestval(k)=val(1);
            subgbest(k,:)=pos(group_id(k,IX(1)),:);               
            
            subgmidval(k)=val(2);
            subgmid(k,:)=pos(group_id(k,IX(2)),:);                  
            
            subgworstval(k)=val(3);
            subgworst(k,:)=pos(group_id(k,IX(3)),:);               
        end
              
    elseif  stagnated>=maxStag  %|| mod(iter,R1)==0 
            stagnated=0;
            
            if  ps>=ps_ini
              %% 
                % 
                exemplar = Breed_exemplar(elites_pos, elites_val, elites_size, group_size*replace_group,pmVar, fitcount, Max_FES, lu);
                exemplar_val=feval(fhd,exemplar',varargin{:})-fbias(func_num);
                fitcount=fitcount+length(exemplar_val);
                % 
                elites_val=(exemplar_val<=elites_val).*exemplar_val + (exemplar_val>elites_val).*elites_val;
                elites_pos=repmat((exemplar_val<=elites_val)',1,D).*exemplar + repmat((exemplar_val>elites_val)',1,D).*elites_pos;
                %
                [B,IX]=sort(exemplar_val,'ascend');                
                exemplar=exemplar(IX(1:group_size*replace_group),:);
                exemplar_val=B(1:group_size*replace_group);
                exemplar_vel=(0.9-0.7*fitcount/Max_FES)*(Vmin(1:group_size*replace_group,:)+2.*Vmax(1:group_size*replace_group,:).*rand(group_size*replace_group,D));
            
            else
              %% 
                % 
                exemplar = Breed_exemplar(elites_pos, elites_val, elites_size, group_size*add_group, pmVar, fitcount, Max_FES, lu);
                exemplar_val=feval(fhd,exemplar',varargin{:})-fbias(func_num);
                fitcount=fitcount+length(exemplar_val);
                % 
                elites_val=(exemplar_val<=elites_val).*exemplar_val + (exemplar_val>elites_val).*elites_val;
                elites_pos=repmat((exemplar_val<=elites_val)',1,D).*exemplar + repmat((exemplar_val>elites_val)',1,D).*elites_pos;
                % 
                [B,IX]=sort(exemplar_val,'ascend');
                exemplar=exemplar(IX(1:group_size*add_group),:);
                exemplar_val=B(1:group_size*add_group);                
                exemplar_vel=(0.9-0.8*fitcount/Max_FES)*(Vmin(1:group_size*add_group,:)+2.*Vmax(1:group_size*add_group,:).*rand(group_size*add_group,D));
            
            end

            if  ps<ps_ini
               % 
                add_elite(1:group_size*add_group,:)=exemplar(1:group_size*add_group,:);
                add_val(1:group_size*add_group)=exemplar_val(1:group_size*add_group);
                add_vel(1:group_size*add_group,:)=exemplar_vel(1:group_size*add_group,:);

                pos=[pos; add_elite]; 
                e=[e,add_val]; 
                vel=[vel; add_vel]; 
                pbest=[pbest; add_elite];
                pbestval=[pbestval, add_val];
                group_num=group_num+add_group;
                ps=ps+group_size*add_group;
                
            else  % 
                %
                [~, replaced_IX]=sort(e,'descend');
                
                tpos=[pos(replaced_IX(1:group_size*replace_group),:); exemplar(1:group_size*replace_group,:)];
                tval=[e(replaced_IX(1:group_size*replace_group)), exemplar_val(1:group_size*replace_group)];
               
                [~, tval_IX]=sort(tval,'ascend');
                pos(replaced_IX(1:group_size*replace_group),:)=tpos(tval_IX(1:group_size*replace_group),:);
                e(replaced_IX(1:group_size*replace_group))=tval(tval_IX(1:group_size*replace_group));

            end
            % 
            group_id=[];pos_group=[];
            subgbestval=[];subgbest=[];
            subgworstval=[];subgworst=[];            
            
            % 
            rc=randperm(ps);
            for k=1:group_num
                group_id(k,:)=rc(((k-1)*group_size+1):k*group_size);
                pos_group(group_id(k,:))=k;
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%
                [val, IX]=sort(e(group_id(k,:)),'ascend'); 
                subgbestval(k)=val(1);%e(group_id(k,IX(1)));
                subgbest(k,:)=pos(group_id(k,IX(1)),:);                 % 
                
                subgmidval(k)=val(2);%e(group_id(k,IX(2)));
                subgmid(k,:)=pos(group_id(k,IX(2)),:);                  % 
                
                subgworstval(k)=val(3);%e(group_id(k,IX(3)));
                subgworst(k,:)=pos(group_id(k,IX(3)),:);                % 
 
%                 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                 [val, IX]=sort(e(group_id(k,:)),'ascend'); 
%                 [subgbestval(k),subgbestid]=min(e(group_id(k,:))); % 
%                 subgbest(k,:)=pos(group_id(k,subgbestid),:);
% 
%                 [subgworstval(k),subgworstid]=max(e(group_id(k,:))); % 
%                 subgworst(k,:)=pos(group_id(k,subgworstid),:);
            end            

    end
    
    iter=iter+1; 
end

 
end

%%%%%%%%%%%%%%%%%%% Ϊĳ����ѡ��ѧϰ���� %%%%%%%%%%%%%%%%%%%%%%%%
function new=Breed_exemplar(elites_pos, elites_val, elites_size, number,pmVar, fes, MaxFEs, lu)
  %%
   
    [~, IX]=min(elites_val);
    gbest=elites_pos(IX,:);
    [N,D]=size(elites_pos);
    index=randperm(N);
    for i=1:N        
        for j=1:N
            if(isequal(elites_pos(i,:),elites_pos(j,:)))
                break;
            end
        end
               
        F=1.0; CR=0.5; pm=0.1;
     %% ................. Mutation ...........................%   
        F=1.0; CR=0.5; pm=0.01; 
%         index(1: 3) = floor(rand(1, 3) * elites_size) + 1;
        
        % Choose the indices for mutation
        indexSet = 1 : elites_size;
        indexSet(i) = [];
        
        % Choose the first index
        temp = floor(rand * (elites_size - 1)) + 1;
        index(1) = indexSet(temp);
        indexSet(temp) = [];
        
        % Choose the second index
        temp = floor(rand * (elites_size - 2)) + 1;
        index(2) = indexSet(temp);
        indexSet(temp) = [];
        
        % Choose the third index
        temp = floor(rand * (elites_size - 3)) + 1;
        index(3) = indexSet(temp);
        indexSet(temp) = [];
        
        % Choose the fourth index
        temp = floor(rand * (elites_size - 4)) + 1;
        index(4) = indexSet(temp);
        indexSet(temp) = [];
        
        % Choose the fifth index
        temp = floor(rand * (elites_size - 5)) + 1;
        index(5) = indexSet(temp);
        
        %% "current-to-rand/1" strategy 
%         v2 = elites_pos(i, :) + rand(1,D) .* (elites_pos(index(1), :) - elites_pos(i, :)) +...
%              rand(1,D) .* (elites_pos(index(2), :) - elites_pos(index(3), :));
        
        %% "rand/1/bin" strategy 
        v2 = elites_pos(index(1), :) + F.* (elites_pos(index(2), :) - elites_pos(index(3), :));
        
        %% "rand/2/bin" strategy 
%         v2 = elites_pos(index(1), :) + rand(1,D).* (elites_pos(index(2), :) - elites_pos(index(3), :)) + rand(1,D).* (elites_pos(index(4), :) - elites_pos(index(5), :));
        
        %% "best/1/bin" strategy
%         v2 = gbest(1, :) + F.* (elites_pos(index(1), :) - elites_pos(index(2), :));
        
        %% "best/2/bin" strategy
%         v2 = gbest(1, :) + rand .* (elites_pos(index(1), :) - elites_pos(index(2), :)) + F.* (elites_pos(index(3), :) - elites_pos(index(4), :));
        
        %% "current-to-best/1/bin" strategy
%         v2 = elites_pos(i,:)+F.*(gbest(1, :)-elites_pos(i,:)) + F.* (elites_pos(index(1), :) - elites_pos(index(2), :));
     
% Handle the elements of the mutant vector which violate the boundary
        vioLow = find(v2 < lu(1, :));
        if ~isempty(vioLow)
            v2(1, vioLow) = 2 .* lu(1, vioLow) - v2(1, vioLow);
            vioLowUpper = find(v2(1, vioLow) > lu(2, vioLow));
            if ~isempty(vioLowUpper)
                v2(1, vioLow(vioLowUpper)) = lu(2, vioLow(vioLowUpper));
            end
        end

        vioUpper = find(v2 > lu(2, :));
        if ~isempty(vioUpper)
            v2(1, vioUpper) = 2 .* lu(2, vioUpper) - v2(1, vioUpper);
            vioUpperLow = find(v2(1, vioUpper) < lu(1, vioUpper));
            if ~isempty(vioUpperLow)
                v2(1, vioUpper(vioUpperLow)) = lu(1, vioUpper(vioUpperLow));
            end
        end
        
        % Binomial crossover
        j_rand = floor(rand * D) + 1;
        t = rand(1, D) < CR;%CR(paraIndex);
        t(1, j_rand) = 1;
        t_ = 1 - t;
        new(i,:) = t .* v2 + t_ .* elites_pos(i,:);
        for j=1:D
            if rand<pm
                new(i,j)=lu(1,D)+rand*(lu(2,D)-lu(1,D));
            end
        end
%                 new(i,:) = v2;

    end  


end

function [pi, vel] = Breed_offspring(pi, vel, pbest, pbestval, lbest, lbestval, gbest, pop, popsize,popval, mv, D, paraIndex, FEs, MaxFEs)
    w=0.9-0.8*FEs/MaxFEs;
    for i=1:popsize
        if(isequal(pi,pop(i,:)))
            break;
        end
    end
    
    indexSet = 1 : popsize;
    indexSet(i) = [];
    temp = floor(rand * (popsize - 1)) + 1;
    IX = indexSet(temp); 

    switch paraIndex       
        case 1  % exploitation
            aa=2.05.*rand(1,D).*(lbest-pi)+2.05.*rand(1,D).*(gbest-pi);            
%            aa=2.05.*rand(1,D).*(pbest-pi)+rand(1,D).*(lbest-pi)+rand(1,D).*(pop(IX,:)-pi);
            vel=w.*vel+aa; 
        
        case 2  % balance
%            aa=2.55.*rand(1,D).*(pbest-pi)+2.05.*rand(1,D).*(gbest-pi);
            aa=2.05.*rand(1,D).*(pbest-pi)+rand(1,D).*(lbest-pi)+rand(1,D).*(pop(IX,:)-pi);
            vel=w.*vel+aa;

        case 3  % exploration            
%             aa=2.55.*rand(1,D).*(pbest-pi)+2.05.*rand(1,D).*(lbest-pi);
            aa=2.05.*rand(1,D).*(pbest-pi)+rand(1,D).*(lbest-pi)+rand(1,D).*(pop(IX,:)-pi);
            vel=w.*(vel+aa);
    end
    
    vel=(vel>mv).*mv+(vel<=mv).*vel;
    vel=(vel<-mv).*(-mv)+(vel>=-mv).*vel;
    pi=pi+vel;

end


