%
% Copyright (c) 2015, Mostapha Kalami Heris & Yarpiz (www.yarpiz.com)
% All rights reserved. Please read the "LICENSE" file for license terms.
%
% Project Code: YPEA101
% Project Title: Implementation of Real-Coded Genetic Algorithm in MATLAB
% Publisher: Yarpiz (www.yarpiz.com)
% 
% Developer: Mostapha Kalami Heris (Member of Yarpiz Team)
% 
% Cite as:
% Mostapha Kalami Heris, Binary and Real-Coded Genetic Algorithms in MATLAB (URL: https://yarpiz.com/23/ypea101-genetic-algorithms), Yarpiz, 2015.
% 
% Contact Info: sm.kalami@gmail.com, info@yarpiz.com
%

% clc;
% clear;
% close all;

function [gbest,gbestval,FES,suc,suc_fes]=rcga_func(jingdu,func_num,fhd,Dimension,group_size,group_num,Max_Gen,Max_FES,Xmin,Xmax,varargin)
% profile on
fes_max=0;
suc=0;
suc_fes=0;
global GFES
GFES=0;
FES=0;
counter=0;
%% Problem Definition

% CostFunction = @(x) Sphere(x);     % Cost Function
% fhd= str2func('Sphere');

% nVar = 10;             % Number of Decision Variables
nVar = Dimension; 
VarSize = [1 nVar];   % Decision Variables Matrix Size

VarMin = Xmin;         % Lower Bound of Variables
VarMax = Xmax;         % Upper Bound of Variables


%% GA Parameters

MaxIt = Max_Gen;     % Maximum Number of Iterations

nPop = group_num;       % Population Size

pc = 0.7;                 % Crossover Percentage
nc = 2*round(pc*nPop/2);  % Number of Offsprings (also Parnets)
gamma = 0.4;              % Extra Range Factor for Crossover

pm = 0.3;                 % Mutation Percentage
nm = round(pm*nPop);      % Number of Mutants
mu = 0.1;         % Mutation Rate

% ANSWER = questdlg('Choose selection method:', 'Genetic Algorithm', ...
%     'Roulette Wheel', 'Tournament', 'Random', 'Roulette Wheel');
% ANSWER='Tournament';
 ANSWER='Roulette Wheel';

UseRouletteWheelSelection = strcmp(ANSWER, 'Roulette Wheel');
UseTournamentSelection = strcmp(ANSWER, 'Tournament');
UseRandomSelection = strcmp(ANSWER, 'Random');

if UseRouletteWheelSelection
    beta = 8; % Selection Pressure
end

if UseTournamentSelection
    TournamentSize = 3;   % Tournamnet Size
end

pause(0.01); % Due to a bug in older versions of MATLAB

%% Initialization

empty_individual.Position = [];
empty_individual.Cost = [];

pop = repmat(empty_individual, nPop, 1);

for i = 1:nPop
    
    % Initialize Position
    pop(i).Position = unifrnd(VarMin, VarMax, VarSize);
    
    % Evaluation
%     pop(i).Cost = CostFunction(pop(i).Position);
    pop(i).Cost = feval(fhd,pop(i).Position,varargin{:});
    
end
FES=FES+nPop;

% Sort Population
Costs = [pop.Cost];
[Costs, SortOrder] = sort(Costs);
pop = pop(SortOrder);

% Store Best Solution
BestSol = pop(1);

% Array to Hold Best Cost Values
BestCost = zeros(MaxIt, 1);

% Store Cost
WorstCost = pop(end).Cost;

%% Main Loop

for it = 1:MaxIt
    
    % Calculate Selection Probabilities
    if UseRouletteWheelSelection
        P = exp(-beta*Costs/WorstCost);
        P = P/sum(P);
    end
    
    % Crossover
    popc = repmat(empty_individual, nc/2, 2);
    for k = 1:nc/2
        
        % Select Parents Indices
        if UseRouletteWheelSelection
            i1 = RouletteWheelSelection(P);
            i2 = RouletteWheelSelection(P);
        end
        if UseTournamentSelection
            i1 = TournamentSelection(pop, TournamentSize);
            i2 = TournamentSelection(pop, TournamentSize);
        end
        if UseRandomSelection
            i1 = randi([1 nPop]);
            i2 = randi([1 nPop]);
        end

        % Select Parents
        p1 = pop(i1);
        p2 = pop(i2);
        
        % Apply Crossover
        [popc(k, 1).Position, popc(k, 2).Position] = Crossover(p1.Position, p2.Position, gamma, VarMin, VarMax);
        
        % Evaluate Offsprings
%         popc(k, 1).Cost = CostFunction(popc(k, 1).Position);
%         popc(k, 2).Cost = CostFunction(popc(k, 2).Position);
        popc(k, 1).Cost = feval(fhd,popc(k, 1).Position,varargin{:});
        popc(k, 2).Cost = feval(fhd,popc(k, 2).Position,varargin{:});
 
        
    end
    FES=FES+nc;
    popc = popc(:);
    
    
    % Mutation
    popm = repmat(empty_individual, nm, 1);
    for k = 1:nm
        
        % Select Parent
        i = randi([1 nPop]);
        p = pop(i);
        
        % Apply Mutation
        popm(k).Position = Mutate(p.Position, mu, VarMin, VarMax);
        
        % Evaluate Mutant
%         popm(k).Cost = CostFunction(popm(k).Position);
        popm(k).Cost = feval(fhd,popm(k).Position,varargin{:});
        
    end
    FES=FES+nm;
    % Create Merged Population
    pop = [pop
         popc
         popm]; %#ok
     
    % Sort Population
    Costs = [pop.Cost];
    [Costs, SortOrder] = sort(Costs);
    pop = pop(SortOrder);
    
    % Update Worst Cost
    WorstCost = max(WorstCost, pop(end).Cost);
    
    % Truncation
    pop = pop(1:nPop);
    Costs = Costs(1:nPop);
    
    % Store Best Solution Ever Found
    BestSol = pop(1);
    
    % Store Best Cost Ever Found
    BestCost(it) = BestSol.Cost;
    
    % Show Iteration Information
%     disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);
    

%     %  termination conditions
%     if it>1
%     if norm(BestCost(it-1)-BestCost(it)) < jingdu % can be changed
%         counter = counter + 1;
%         if counter > 0.02*MaxIt % can be changed
%             break;
%         end
%     else
%         counter = 0;
%     end
%     end
    
    if GFES>Max_FES
        break;
    end
    
    
end
gbest=BestSol;
gbestval=BestSol.Cost;
% profile viewer
end
%% Results

% figure;
% semilogy(BestCost, 'LineWidth', 2);
% % plot(BestCost, 'LineWidth', 2);
% xlabel('Iteration');
% ylabel('Cost');
% grid on;
