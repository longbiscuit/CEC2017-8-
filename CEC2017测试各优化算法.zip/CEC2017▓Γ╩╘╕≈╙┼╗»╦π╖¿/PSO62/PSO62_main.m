%
% Copyright (c) 2015, Mostapha Kalami Heris & Yarpiz (www.yarpiz.com)
% All rights reserved. Please read the "LICENSE" file for license terms.
%
% Project Code: YPEA101
% Project Title: Implementation of Real-Coded Genetic Algorithm in MATLAB
% Publisher: Yarpiz (www.yarpiz.com)
% 
% Developer: Mostapha Kalami Heris (Member of Yarpiz Team)
% 
% Cite as:
% Mostapha Kalami Heris, Binary and Real-Coded Genetic Algorithms in MATLAB (URL: https://yarpiz.com/23/ypea101-genetic-algorithms), Yarpiz, 2015.
% 
% Contact Info: sm.kalami@gmail.com, info@yarpiz.com
%
clear all
clc
format long;
global fbias
diary on % Open log to record all command window commands and output
diary('Log.DAT');% Print the log and save it

D=10
Xmin=-100;
Xmax=100;

warning('off')
% pop_size=40;%2^(4+floor(log2(sqrt(D))));
% fes_max=10000*D;
% iter_max=ceil(fes_max/pop_size);

pop_size=D*10;%2^(4+floor(log2(sqrt(D))));
fes_max=20000*D;
iter_max=ceil(fes_max/pop_size);

runtimes=50;
% fhd=str2func('cec17_func');
fhd=str2func('cec17_funcMex');
fbias=[100, 200, 300, 400, 500,...
       600, 700, 800, 900, 1000,...
       1100,1200,1300,1400,1500,...
       1600,1700,1800,1900,2000,...
       2100,2200,2300,2400,2500,...
       2600,2700,2800,2900,3000 ];
% jingdu=1e-8;
jingdu=0;

funset=[1:30];%
'PSO62'  %
for fun=1:length(funset)
    func_num=funset(fun);
    suc_times = 0; 
    
    fesusage=0;
    count=0;
    
    for runs=1:runtimes
        suc = 0;
        suc_fes = 0;   
        tic;
        group_size=3; group_num=D*10; % group_num=20+round(D/10); MAPSO_func(jingdu,func_num,fhd,Dimension,group_size,group_num,Max_Gen,Max_FES,Xmin,Xmax,varargin) 
        [gbest,gbestval,FES,suc,suc_fes]= pso62_func(jingdu,func_num,fhd,D,group_size,group_num,iter_max,fes_max,Xmin,Xmax,func_num);

        t=toc;
        time_usage(runs,fun)=t;
        
        xbest(runs,:)=gbest;
        fbest(runs,func_num)=gbestval;
        fprintf('�� %d �����е����Ž��Ϊ��%1.4e\n',runs,gbestval);
        suc_times = suc_times + suc;
        if suc == 1     
            fesusage = fesusage + suc_fes;          
        end        
    end
     

    SR(1,func_num) = suc_times/runtimes;
    if suc_times>0
        FEs(1,func_num) = fesusage/suc_times;  
        SP (1,func_num) = fes_max*(1-SR(1,func_num))/SR(1,func_num) + FEs(1,func_num);
    else
        FEs(1,func_num) = -1;  
        SP (1,func_num) = -1; 
    end
    
    f_mean(func_num)=mean(fbest(:,func_num));
    f_std(func_num)=std(fbest(:,func_num));
    fprintf('\nFunction F%d :\nAvg. fitness = %1.2e(%1.2e)\n\n',func_num,mean(fbest(:,func_num)),std(fbest(:,func_num)));    
    fprintf(' -------------------------------------------------- \n');
    
end
time_usage
f_mean=f_mean'
f_std=f_std'
diary off;



